"""
Cursor Rules CLI - A tool to scan projects and suggest relevant Cursor rules
"""

__version__ = "0.5.2" 